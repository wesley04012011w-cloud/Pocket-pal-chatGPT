import { existsSync, mkdirSync, copyFileSync, cpSync, readFileSync, writeFileSync } from "node:fs";
import { execSync } from "node:child_process";

if (!existsSync("node_modules")) execSync("npm install", {stdio:"inherit"});
if (!existsSync("android")) execSync("npx cap add android", {stdio:"inherit"});

const app = "android/app/src/main";
mkdirSync(`${app}/java/dev/pocketpal/local`, {recursive:true});
mkdirSync(`${app}/cpp`, {recursive:true});

for (const file of ["NativeBridge.kt","LocalLlamaPlugin.kt"]) {
  copyFileSync(`native/android/${file}`, `${app}/java/dev/pocketpal/local/${file}`);
}
copyFileSync("native/android/LlamaEngine.cpp", `${app}/cpp/LlamaEngine.cpp`);
copyFileSync("native/android/CMakeLists.txt", `${app}/cpp/CMakeLists.txt`);

const mainActivity = `${app}/java/dev/pocketpal/local/MainActivity.kt`;
writeFileSync(mainActivity, `package dev.pocketpal.local

import com.getcapacitor.BridgeActivity

class MainActivity : BridgeActivity() {
    override fun onCreate(state: android.os.Bundle?) {
        registerPlugin(LocalLlamaPlugin::class.java)
        super.onCreate(state)
    }
}
`);

const gradle = "android/app/build.gradle";
let g = readFileSync(gradle, "utf8");
if (!g.includes("externalNativeBuild")) {
  g += `

android {
    defaultConfig {
        externalNativeBuild {
            cmake { cppFlags "-std=c++17" }
        }
        ndk { abiFilters "arm64-v8a", "x86_64" }
    }
    externalNativeBuild {
        cmake { path file("src/main/cpp/CMakeLists.txt") }
    }
}
`;
  writeFileSync(gradle, g);
}
console.log("Android shell prepared.");

# PocketPal Local — local LLM app starter

A modern 2026-style local LLM client for Android, inspired by the *interaction model* of PocketPal, but with an independent implementation and visual identity.

- **UI:** React + Vite + Capacitor
- **Native engine:** C++/JNI
- **Inference:** llama.cpp
- **Model format:** GGUF
- **Chat templates:** model metadata + custom Jinja through llama.cpp `common`
- **Thinking:** native template flags + UI separation of `<think>…</think>` / reasoning channels
- **Markdown:** GitHub-flavored Markdown rendering, code blocks, tables, lists, blockquotes, math-friendly fenced blocks
- **Controls:** context, CPU threads, batch threads, Flash Attention, mmap, mlock, temperature, top-p, top-k, min-p, repeat penalty, seed, Jinja, thinking
- **Workflow:** `.github/workflows/build-android.yml` compiles the project after extracting the ZIP; `llama.cpp` is fetched during the build.

> This repository is a starter/reference implementation. It intentionally does **not** vendor the large `llama.cpp` source tree or model weights.

## Quick start

### Requirements

- Node.js 22+
- JDK 17+
- Android SDK + NDK 27+
- CMake 3.31+
- A GGUF model

```bash
npm install
npm run android:prepare
npm run android:sync
npm run android:open
```

The first native build downloads the pinned llama.cpp source.

### Project layout

```text
pocketpal-local/
├─ src/                         # modern React UI
├─ native/android/              # JNI + Capacitor native plugin
├─ scripts/prepare-android.mjs  # creates/patches the Capacitor Android shell
├─ .github/workflows/           # ZIP-oriented CI
├─ docs/GITHUB_ACTIONS.md       # complete CI explanation
└─ capacitor.config.ts
```

## Architecture

```text
React UI
   │
   │ Capacitor bridge
   ▼
Kotlin LocalLlamaPlugin
   │
   │ JNI
   ▼
C++ LocalLlamaEngine
   │
   ├── llama.cpp
   ├── GGUF loader
   ├── Jinja/minja chat templates
   ├── samplers
   └── streaming tokens
```

The native layer owns model/context/sampler lifetime. The web layer never loads the GGUF into JavaScript memory.

## Important limitations of this starter

1. The first target is **Android CPU inference**. The project is structured so Vulkan/NNAPI/vendor GPU backends can be added later without redesigning the UI.
2. `n_gpu_layers` is deliberately not exposed yet because mobile GPU backends are device-specific.
3. Jinja support is routed through llama.cpp's `common` library. The exact model template remains authoritative; the app does not attempt to invent a universal prompt format.
4. Thinking is parsed for display, but the model still controls the actual reasoning tokens/template.
5. Model files remain on-device. No cloud API is required.

## License

The application code in this repository is intended to be MIT licensed. `llama.cpp` remains under its own license and is fetched separately at build time.

## llama.cpp compatibility

The Android native bridge is pinned to `v0.4.1`. The pinned release exposes the model-loading, context, sampler, batch, Flash Attention, mmap and Jinja/common chat-template APIs used by this project. The prompt tokenizer also handles llama.cpp's negative required-token-count return convention.

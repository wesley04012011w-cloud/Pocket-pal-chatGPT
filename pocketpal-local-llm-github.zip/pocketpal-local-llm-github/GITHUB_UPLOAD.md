# Upload para GitHub

Este pacote foi limpo e validado para upload. Não contém `node_modules`, caches, `.git` ou binários de build.

Se você quer manter o projeto inteiro dentro de um único ZIP no GitHub, coloque o arquivo `pocketpal-local-llm.zip` na raiz do repositório e use o workflow `build-from-zip.yml`.

# Feature map

| Feature | Status | Native path |
|---|---|---|
| GGUF loading | Included | llama.cpp |
| CPU threads | Included | `llama_context_params.n_threads` |
| Batch threads | Included | `n_threads_batch` |
| Context length | Included | `n_ctx` |
| Flash Attention | Included | `flash_attn_type` |
| mmap / no-mmap | Included | `llama_model_params.use_mmap` |
| mlock | Included | `llama_model_params.use_mlock` |
| Jinja templates | Included | llama.cpp `common` / minja |
| Model metadata template | Included | `llama_model_chat_template` |
| Thinking | Included | template `enable_thinking` + UI parser |
| Markdown | Included | `marked` / GFM |
| Temperature | Included | sampler |
| Top-K / Top-P / Min-P | Included | sampler |
| Seed | Included | sampler |
| GPU offload | Planned | Vulkan/Metal/NNAPI/device-specific |
| Vision/audio | Planned | llama.cpp mtmd |
| Tool calling | Planned | common chat parser |
| Speculative decoding | Planned | draft model / MTP |
| LoRA | Planned | llama adapter API |
| Embeddings | Planned | llama embedding context |

## Markdown/tag compatibility

The renderer intentionally accepts model output as Markdown instead of stripping tags. This preserves:

- headings
- emphasis / strong emphasis
- inline code
- fenced code blocks
- ordered and unordered lists
- tables
- blockquotes
- links
- `<think>…</think>` reasoning blocks for UI separation
- ordinary HTML-like model tags as text where Markdown does not treat them as executable HTML.

For production, add sanitization before rendering untrusted HTML output.

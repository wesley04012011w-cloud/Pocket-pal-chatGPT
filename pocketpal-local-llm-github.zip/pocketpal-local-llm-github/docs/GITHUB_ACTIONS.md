# GitHub Actions — build directly from the ZIP

The intended distribution model for this starter is:

1. Download the project ZIP.
2. Create a GitHub repository.
3. Add the ZIP as a single repository file (or upload it through the web UI).
4. The workflow extracts the ZIP into the workspace.
5. Node dependencies are installed.
6. Capacitor generates the Android shell.
7. `llama.cpp` is cloned at the pinned version.
8. Native C++/JNI is compiled by Android Gradle/CMake.
9. A debug APK is uploaded as a workflow artifact.

The repository **does not need the `android/` generated directory or the `llama.cpp/` source tree committed**.

## Recommended repository layout

If GitHub contains the extracted project:

```text
.github/workflows/build-android.yml
capacitor.config.ts
package.json
src/
native/
scripts/
docs/
```

The ZIP itself is the complete source package. If you instead commit the ZIP as `project.zip`, the included workflow can extract that archive automatically; see the optional variant below.

## Workflow

The included `.github/workflows/build-android.yml` assumes the ZIP contents are already the repository files. It is intentionally simple and reproducible.

For a repository where the **only source file is `pocketpal-local-llm.zip`**, use:

```yaml
name: Build Android from ZIP

on:
  workflow_dispatch:
  push:
    paths:
      - "pocketpal-local-llm.zip"
      - ".github/workflows/build-from-zip.yml"

jobs:
  android:
    runs-on: ubuntu-24.04
    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Extract source ZIP
        run: |
          rm -rf extracted
          mkdir extracted
          unzip -q pocketpal-local-llm.zip -d extracted
          # Remove a possible single top-level directory.
          if [ "$(find extracted -mindepth 1 -maxdepth 1 -type d | wc -l)" = "1" ] && \
             [ "$(find extracted -mindepth 1 -maxdepth 1 -type f | wc -l)" = "0" ]; then
            inner="$(find extracted -mindepth 1 -maxdepth 1 -type d | head -1)"
            shopt -s dotglob
            mv "$inner"/* extracted/
            rmdir "$inner"
          fi

      - name: Setup Java
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: "17"

      - name: Setup Node
        uses: actions/setup-node@v4
        with:
          node-version: "22"
          cache: npm
          cache-dependency-path: extracted/package.json

      - name: Install Android SDK
        uses: android-actions/setup-android@v3

      - name: Install dependencies
        working-directory: extracted
        run: npm install

      - name: Prepare Capacitor + native engine
        working-directory: extracted
        run: npm run android:prepare

      - name: Fetch pinned llama.cpp
        working-directory: extracted
        run: |
          git clone --depth 1 --branch "$(cat llama.cpp.version)" \
            https://github.com/ggml-org/llama.cpp.git llama.cpp

      - name: Build web and Android
        working-directory: extracted
        run: |
          npm run android:sync
          cd android
          ./gradlew assembleDebug --no-daemon --stacktrace

      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: pocketpal-local-debug-apk
          path: extracted/android/app/build/outputs/apk/debug/*.apk
```

## Why `llama.cpp` is fetched separately

The native dependency is large and changes independently of the application. Keeping it outside the ZIP:

- keeps the source archive small;
- makes the app source easier to review;
- avoids accidentally committing model weights;
- lets the workflow pin a known llama.cpp release.

The included pin is `v0.1.2`. llama.cpp currently documents a transition toward semantic releases, while nightly `bNNNN` tags are also published frequently. Update `llama.cpp.version` deliberately when upgrading the native API.

## Local build

```bash
npm install
npm run android:prepare
git clone --depth 1 --branch "$(cat llama.cpp.version)" \
  https://github.com/ggml-org/llama.cpp.git
npm run android:sync
cd android
./gradlew assembleDebug
```

## Future CI matrix

For production, split the native build into separate variants:

- `arm64-v8a` CPU
- `arm64-v8a` Vulkan
- `x86_64` emulator
- release signing
- Play App Bundle (`bundleRelease`)

Do not enable every accelerator in one APK without testing device compatibility and binary size.

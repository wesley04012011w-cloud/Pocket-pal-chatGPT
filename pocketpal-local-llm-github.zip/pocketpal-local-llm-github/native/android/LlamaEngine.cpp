#include <jni.h>
#include <android/log.h>
#include <atomic>
#include <mutex>
#include <string>
#include <vector>
#include <thread>
#include <algorithm>

#include "llama.h"
#include "chat.h"

#define TAG "PocketPalLocal"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static std::mutex g_mutex;
static llama_model * g_model = nullptr;
static llama_context * g_ctx = nullptr;
static llama_sampler * g_sampler = nullptr;
static std::atomic_bool g_stop{false};

static std::string jstr(JNIEnv *env, jstring s) {
    if (!s) return {};
    const char *p = env->GetStringUTFChars(s, nullptr);
    std::string out = p ? p : "";
    env->ReleaseStringUTFChars(s, p);
    return out;
}

static std::string render_chat(const std::vector<std::pair<std::string,std::string>>& msgs, bool jinja, bool thinking) {
    std::vector<common_chat_msg> cm;
    cm.reserve(msgs.size());
    for (auto &m : msgs) {
        common_chat_msg x;
        x.role = m.first;
        x.content = m.second;
        cm.push_back(std::move(x));
    }

    if (!g_model) return {};
    auto templates = common_chat_templates_init(g_model, "");
    common_chat_templates_inputs in;
    in.messages = cm;
    in.use_jinja = jinja;
    in.add_generation_prompt = true;
    in.enable_thinking = thinking;
    in.reasoning_format = COMMON_REASONING_FORMAT_AUTO;
    return common_chat_templates_apply(templates.get(), in).prompt;
}

static bool decode_prompt(const std::string &prompt, std::vector<llama_token> &tokens) {
    const llama_vocab *vocab = llama_model_get_vocab(g_model);
    const int32_t n = llama_tokenize(vocab, prompt.c_str(), (int32_t)prompt.size(),
                                     nullptr, 0, true, true);
    if (n <= 0) return false;
    tokens.resize((size_t)n);
    const int32_t got = llama_tokenize(vocab, prompt.c_str(), (int32_t)prompt.size(),
                                       tokens.data(), n, true, true);
    return got == n;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_dev_pocketpal_local_NativeBridge_nativeLoad(
        JNIEnv *env, jclass, jstring path, jint nctx, jint threads, jint batchThreads,
        jint batch, jboolean flash, jboolean mmap, jboolean mlock) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }

    llama_backend_init();
    auto mp = llama_model_default_params();
    mp.n_gpu_layers = 0;
    mp.use_mmap = mmap;
    mp.use_mlock = mlock;

    const std::string p = jstr(env, path);
    g_model = llama_model_load_from_file(p.c_str(), mp);
    if (!g_model) {
        LOGE("Failed to load model: %s", p.c_str());
        return JNI_FALSE;
    }

    auto cp = llama_context_default_params();
    cp.n_ctx = (uint32_t)nctx;
    cp.n_batch = (uint32_t)batch;
    cp.n_threads = threads;
    cp.n_threads_batch = batchThreads;
    cp.flash_attn_type = flash ? LLAMA_FLASH_ATTN_TYPE_ENABLED : LLAMA_FLASH_ATTN_TYPE_DISABLED;

    g_ctx = llama_init_from_model(g_model, cp);
    if (!g_ctx) {
        llama_model_free(g_model);
        g_model = nullptr;
        return JNI_FALSE;
    }

    g_sampler = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(g_sampler, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(g_sampler, llama_sampler_init_top_p(0.95f, 1));
    llama_sampler_chain_add(g_sampler, llama_sampler_init_min_p(0.05f, 1));
    llama_sampler_chain_add(g_sampler, llama_sampler_init_temp(0.7f));
    llama_sampler_chain_add(g_sampler, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
    return JNI_TRUE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_dev_pocketpal_local_NativeBridge_nativeTemplate(
        JNIEnv *env, jclass) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_model) return env->NewStringUTF("");
    const char *t = llama_model_chat_template(g_model, nullptr);
    return env->NewStringUTF(t ? t : "");
}

extern "C" JNIEXPORT void JNICALL
Java_dev_pocketpal_local_NativeBridge_nativeStop(JNIEnv *, jclass) {
    g_stop.store(true);
}

extern "C" JNIEXPORT void JNICALL
Java_dev_pocketpal_local_NativeBridge_nativeFree(JNIEnv *, jclass) {
    std::lock_guard<std::mutex> lock(g_mutex);
    g_stop.store(true);
    if (g_sampler) { llama_sampler_free(g_sampler); g_sampler = nullptr; }
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
    llama_backend_free();
}

extern "C" JNIEXPORT jboolean JNICALL
Java_dev_pocketpal_local_NativeBridge_nativeGenerateChat(
        JNIEnv *env, jclass, jobjectArray roles, jobjectArray contents,
        jint maxTokens, jfloat temperature, jfloat topP, jint topK, jfloat minP, jlong seed,
        jobject callback) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_ctx || !g_model) return JNI_FALSE;
    g_stop.store(false);

    // Rebuild sampler per request so the UI controls are applied immediately.
    if (g_sampler) llama_sampler_free(g_sampler);
    g_sampler = llama_sampler_chain_init(llama_sampler_chain_default_params());
    if (topK > 0) llama_sampler_chain_add(g_sampler, llama_sampler_init_top_k(topK));
    llama_sampler_chain_add(g_sampler, llama_sampler_init_top_p(topP, 1));
    llama_sampler_chain_add(g_sampler, llama_sampler_init_min_p(minP, 1));
    llama_sampler_chain_add(g_sampler, llama_sampler_init_temp(temperature));
    llama_sampler_chain_add(g_sampler, llama_sampler_init_dist((uint32_t)seed));

    std::vector<std::pair<std::string,std::string>> msgs;
    const jsize count = env->GetArrayLength(roles);
    for (jsize i = 0; i < count; ++i) {
        auto jr = (jstring) env->GetObjectArrayElement(roles, i);
        auto jc = (jstring) env->GetObjectArrayElement(contents, i);
        msgs.emplace_back(jstr(env, jr), jstr(env, jc));
        env->DeleteLocalRef(jr);
        env->DeleteLocalRef(jc);
    }

    const std::string prompt = render_chat(msgs, true, true);
    std::vector<llama_token> tokens;
    if (!decode_prompt(prompt, tokens)) return JNI_FALSE;

    llama_memory_clear(llama_get_memory(g_ctx), true);
    llama_batch batch = llama_batch_get_one(tokens.data(), (int32_t)tokens.size());
    if (llama_decode(g_ctx, batch) != 0) return JNI_FALSE;

    const llama_vocab *vocab = llama_model_get_vocab(g_model);
    llama_token eos = llama_vocab_eos(vocab);
    jclass cls = env->GetObjectClass(callback);
    jmethodID emit = env->GetMethodID(cls, "emit", "(Ljava/lang/String;Z)V");
    if (!emit) return JNI_FALSE;

    for (int i = 0; i < maxTokens && !g_stop.load(); ++i) {
        llama_token tok = llama_sampler_sample(g_sampler, g_ctx, -1);
        llama_sampler_accept(g_sampler, tok);
        if (tok == eos) break;

        char buf[4096];
        int32_t n = llama_token_to_piece(vocab, tok, buf, sizeof(buf), 0, true);
        if (n > 0) {
            jstring piece = env->NewStringUTF(std::string(buf, n).c_str());
            env->CallVoidMethod(callback, emit, piece, JNI_FALSE);
            env->DeleteLocalRef(piece);
        }
        batch = llama_batch_get_one(&tok, 1);
        if (llama_decode(g_ctx, batch) != 0) break;
    }

    jstring empty = env->NewStringUTF("");
    env->CallVoidMethod(callback, emit, empty, JNI_TRUE);
    env->DeleteLocalRef(empty);
    return JNI_TRUE;
}

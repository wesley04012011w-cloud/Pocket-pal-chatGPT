package dev.pocketpal.local

import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import com.getcapacitor.*
import java.io.File

@CapacitorPlugin(name = "LlamaEngine")
class LocalLlamaPlugin : Plugin() {
    @PluginMethod
    fun pickModel(call: PluginCall) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/octet-stream"
        }
        startActivityForResult(call, intent, "modelPicker")
    }

    @ActivityCallback
    fun modelPicker(call: PluginCall, result: ActivityResult) {
        if (result.resultCode != android.app.Activity.RESULT_OK) { call.reject("Picker cancelled"); return }
        val uri: Uri = result.data?.data ?: run { call.reject("No file selected"); return }
        val name = queryName(uri) ?: "model.gguf"
        val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val dst = File(context.filesDir, "models/$safe")
        dst.parentFile?.mkdirs()
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input)
            dst.outputStream().use { output -> input.copyTo(output, 1024 * 1024) }
        }
        val size = dst.length()
        call.resolve(JSObject().apply {
            put("path", dst.absolutePath); put("name", safe); put("size", size)
        })
    }

    private fun queryName(uri: Uri): String? {
        context.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && c.moveToFirst()) return c.getString(idx)
        }
        return uri.lastPathSegment
    }

    @PluginMethod
    fun loadModel(call: PluginCall) {
        val path = call.getString("path") ?: return call.reject("Missing path")
        val s = call.getJSObject("settings") ?: return call.reject("Missing settings")
        val ok = NativeBridge.nativeLoad(
            path,
            s.getInt("context", 8192),
            s.getInt("threads", Runtime.getRuntime().availableProcessors().coerceAtMost(8)),
            s.getInt("batchThreads", Runtime.getRuntime().availableProcessors().coerceAtMost(8)),
            s.getInt("batch", 512),
            s.getBoolean("flashAttention", true),
            s.getBoolean("mmap", true),
            s.getBoolean("mlock", false)
        )
        val template = if (ok) NativeBridge.nativeTemplate() else ""
        call.resolve(JSObject().apply {
            put("ok", ok); put("template", template); put("description", "llama.cpp native engine")
        })
    }

    @PluginMethod
    fun generate(call: PluginCall) {
        val messages = call.getArray("messages") ?: return call.reject("Missing messages")
        val s = call.getJSObject("settings") ?: return call.reject("Missing settings")
        val roles = Array(messages.length()) { "" }
        val contents = Array(messages.length()) { "" }
        for (i in 0 until messages.length()) {
            val m = messages.getJSONObject(i)
            roles[i] = m.getString("role")
            contents[i] = m.getString("content")
        }
        Thread {
            val ok = NativeBridge.nativeGenerateChat(
                roles,
                contents,
                s.getInt("maxTokens", 1024),
                s.getDouble("temperature", .7).toFloat(),
                s.getDouble("topP", .95).toFloat(),
                s.getInt("topK", 40),
                s.getDouble("minP", .05).toFloat(),
                s.getLong("seed", -1L),
                object : TokenCallback {
                    override fun emit(text: String, done: Boolean) {
                        notifyListeners("token", JSObject().apply {
                            put("text", text); put("done", done)
                        })
                    }
                }
            )
            if (!ok) notifyListeners("token", JSObject().apply {
                put("text", "\n\n[Native inference error]"); put("done", true)
            })
            call.resolve(JSObject().apply { put("ok", ok) })
        }.start()
    }

    @PluginMethod fun stop(call: PluginCall) { NativeBridge.nativeStop(); call.resolve(JSObject().apply{put("ok",true)}) }
    @PluginMethod fun unload(call: PluginCall) { NativeBridge.nativeFree(); call.resolve(JSObject().apply{put("ok",true)}) }
    @PluginMethod fun getCapabilities(call: PluginCall) {
        call.resolve(JSObject().apply {
            put("mmap", true); put("mlock", true); put("gpu", false); put("jinja", true)
        })
    }
}

package dev.pocketpal.local

object NativeBridge {
    init { System.loadLibrary("pocketpal_local") }

    @JvmStatic external fun nativeLoad(
        path: String, nctx: Int, threads: Int, batchThreads: Int, batch: Int,
        flash: Boolean, mmap: Boolean, mlock: Boolean
    ): Boolean

    @JvmStatic external fun nativeTemplate(): String
    @JvmStatic external fun nativeStop()
    @JvmStatic external fun nativeFree()

    @JvmStatic external fun nativeGenerateChat(
        roles: Array<String>, contents: Array<String>, maxTokens: Int, temperature: Float, topP: Float,
        topK: Int, minP: Float, seed: Long, callback: TokenCallback
    ): Boolean
}

interface TokenCallback { fun emit(text: String, done: Boolean) }

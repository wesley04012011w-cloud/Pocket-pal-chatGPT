import { registerPlugin } from "@capacitor/core";

export type NativeSettings = {
  context: number;
  threads: number;
  batchThreads: number;
  batch: number;
  flashAttention: boolean;
  mmap: boolean;
  mlock: boolean;
  temperature: number;
  topP: number;
  topK: number;
  minP: number;
  repeatPenalty: number;
  seed: number;
  jinja: boolean;
  thinking: boolean;
  maxTokens: number;
};

export type TokenEvent = {
  text: string;
  done?: boolean;
  promptTokens?: number;
  generatedTokens?: number;
};

export interface LlamaEnginePlugin {
  pickModel(): Promise<{ path: string; name: string; size: number }>;
  loadModel(options: { path: string; settings: NativeSettings }): Promise<{ ok: boolean; template: string; description: string }>;
  generate(options: { messages: Array<{role: string; content: string}>; settings: NativeSettings }): Promise<{ ok: boolean }>;
  stop(): Promise<{ ok: boolean }>;
  unload(): Promise<{ ok: boolean }>;
  getCapabilities(): Promise<{ mmap: boolean; mlock: boolean; gpu: boolean; jinja: boolean }>;
  addListener(eventName: "token", listener: (event: TokenEvent) => void): Promise<{ remove: () => Promise<void> }>;
}

export const LlamaEngine = registerPlugin<LlamaEnginePlugin>("LlamaEngine");

import { useEffect, useMemo, useState } from "react";
import { Bot, ChevronDown, Cpu, Download, FileCode2, Menu, MessageSquare, PanelLeft, Play, Plus, Settings2, SlidersHorizontal, Sparkles, Square, Terminal, X } from "lucide-react";
import { marked } from "marked";
import { LlamaEngine, NativeSettings } from "./native";

type Message = { role: "user" | "assistant"; content: string; reasoning?: string; streaming?: boolean };

const defaults: NativeSettings = {
  context: 8192, threads: 6, batchThreads: 6, batch: 512, flashAttention: true,
  mmap: true, mlock: false, temperature: 0.7, topP: 0.95, topK: 40, minP: 0.05,
  repeatPenalty: 1.05, seed: -1, jinja: true, thinking: true, maxTokens: 1024
};

function renderMarkdown(text: string) {
  return { __html: marked.parse(text, { breaks: true, gfm: true }) as string };
}

function splitThinking(text: string) {
  const match = text.match(/<think>([\s\S]*?)<\/think>/i);
  if (!match) return { answer: text, reasoning: "" };
  return { answer: text.replace(match[0], "").trim(), reasoning: match[1].trim() };
}

export default function App() {
  const [messages, setMessages] = useState<Message[]>([
    { role: "assistant", content: "Local inference is ready. Import a GGUF model to begin." }
  ]);
  const [input, setInput] = useState("");
  const [settings, setSettings] = useState(defaults);
  const [model, setModel] = useState<{name: string; path: string; size: number} | null>(null);
  const [loaded, setLoaded] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [drawer, setDrawer] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [status, setStatus] = useState("Idle");
  const [template, setTemplate] = useState("auto");

  useEffect(() => {
    let listener: { remove: () => Promise<void> } | undefined;
    LlamaEngine.addListener("token", event => {
      setMessages(prev => {
        const copy = [...prev];
        const idx = copy.length - 1;
        if (copy[idx]?.role !== "assistant") return copy;
        copy[idx] = { ...copy[idx], content: copy[idx].content + event.text, streaming: !event.done };
        return copy;
      });
      if (event.done) {
        setGenerating(false);
        setStatus("Ready");
      }
    }).then(x => listener = x).catch(() => {});
    return () => { listener?.remove(); };
  }, []);

  const canGenerate = useMemo(() => Boolean(input.trim() && loaded && !generating), [input, loaded, generating]);

  async function importModel() {
    try {
      const picked = await LlamaEngine.pickModel();
      setModel(picked);
      setStatus("Loading model…");
      const result = await LlamaEngine.loadModel({ path: picked.path, settings });
      setTemplate(result.template || "auto");
      setLoaded(result.ok);
      setStatus(result.ok ? "Ready" : "Load failed");
    } catch (e) {
      setStatus(String(e));
    }
  }

  async function send() {
    if (!canGenerate) return;
    const user = input.trim();
    const next = [...messages, { role: "user" as const, content: user }, { role: "assistant" as const, content: "", streaming: true }];
    setMessages(next);
    setInput("");
    setGenerating(true);
    setStatus("Generating…");
    try {
      await LlamaEngine.generate({ messages: next.filter(m => !m.streaming).map(({role, content}) => ({role, content})), settings });
    } catch (e) {
      setGenerating(false);
      setStatus(String(e));
    }
  }

  function clearChat() {
    setMessages([{ role: "assistant", content: "New chat. Your model remains loaded." }]);
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <button className="icon-btn" onClick={() => setDrawer(v => !v)} aria-label="Menu"><Menu size={20}/></button>
        <div className="brand"><div className="brand-mark"><Sparkles size={17}/></div><span>PocketPal Local</span></div>
        <div className="top-actions">
          <button className="pill-btn" onClick={importModel}><Download size={16}/>{model ? model.name : "Import GGUF"}</button>
          <button className="icon-btn" onClick={() => setShowSettings(v => !v)}><SlidersHorizontal size={19}/></button>
        </div>
      </header>

      <div className="workspace">
        <aside className={`sidebar ${drawer ? "open" : ""}`}>
          <div className="sidebar-head"><span>Chats</span><button className="icon-btn" onClick={clearChat}><Plus size={18}/></button></div>
          <button className="chat-row active"><MessageSquare size={17}/><span>Local session</span></button>
          <div className="sidebar-bottom">
            <div className="model-card">
              <div className="model-icon"><Cpu size={17}/></div>
              <div><b>{model?.name || "No model"}</b><small>{loaded ? "Loaded locally" : "Import a GGUF model"}</small></div>
              <span className={`dot ${loaded ? "on" : ""}`}/>
            </div>
          </div>
        </aside>

        <main className="chat">
          <div className="chat-head">
            <div><div className="eyebrow">LOCAL ENGINE</div><h1>{model?.name || "Your private AI"}</h1></div>
            <div className="status"><span className={`dot ${loaded ? "on" : ""}`}/>{status}</div>
          </div>

          <div className="messages">
            {messages.map((m, i) => {
              const parsed = m.role === "assistant" ? splitThinking(m.content) : {answer: m.content, reasoning: ""};
              return <article key={i} className={`message ${m.role}`}>
                {m.role === "assistant" && <div className="avatar"><Bot size={18}/></div>}
                <div className="bubble">
                  {parsed.reasoning && <details className="thinking" open={generating}><summary>Thinking</summary><div>{parsed.reasoning}</div></details>}
                  {m.role === "assistant" ? <div className="markdown" dangerouslySetInnerHTML={renderMarkdown(parsed.answer)} /> : <div>{m.content}</div>}
                  {m.streaming && <span className="cursor"/>}
                </div>
              </article>;
            })}
          </div>

          <div className="composer-wrap">
            <div className="composer">
              <textarea value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => {if(e.key === "Enter" && !e.shiftKey){e.preventDefault();send();}}} placeholder={loaded ? "Message your local model…" : "Import a GGUF model first…"} disabled={!loaded}/>
              <div className="composer-bar">
                <div className="composer-meta"><span><Terminal size={14}/> {template}</span><span><FileCode2 size={14}/> {settings.jinja ? "Jinja" : "Raw prompt"}</span></div>
                {generating ? <button className="send-btn stop" onClick={() => LlamaEngine.stop()}><Square size={16} fill="currentColor"/></button> : <button className="send-btn" disabled={!canGenerate} onClick={send}><Play size={16} fill="currentColor"/></button>}
              </div>
            </div>
          </div>
        </main>

        {showSettings && <section className="settings-panel">
          <div className="settings-head"><div><div className="eyebrow">ENGINE</div><h2>Inference</h2></div><button className="icon-btn" onClick={() => setShowSettings(false)}><X size={19}/></button></div>
          <Setting label="Context" value={settings.context} min={1024} max={32768} step={1024} onChange={v => setSettings({...settings, context:v})}/>
          <Setting label="CPU threads" value={settings.threads} min={1} max={32} step={1} onChange={v => setSettings({...settings, threads:v})}/>
          <Setting label="Batch threads" value={settings.batchThreads} min={1} max={32} step={1} onChange={v => setSettings({...settings, batchThreads:v})}/>
          <Setting label="Temperature" value={settings.temperature} min={0} max={2} step={0.05} onChange={v => setSettings({...settings, temperature:v})}/>
          <Setting label="Top P" value={settings.topP} min={0} max={1} step={0.01} onChange={v => setSettings({...settings, topP:v})}/>
          <Setting label="Min P" value={settings.minP} min={0} max={1} step={0.01} onChange={v => setSettings({...settings, minP:v})}/>
          <Setting label="Top K" value={settings.topK} min={0} max={200} step={1} onChange={v => setSettings({...settings, topK:v})}/>
          <div className="toggle-row"><span>Flash Attention</span><input type="checkbox" checked={settings.flashAttention} onChange={e=>setSettings({...settings,flashAttention:e.target.checked})}/></div>
          <div className="toggle-row"><span>Memory map (mmap)</span><input type="checkbox" checked={settings.mmap} onChange={e=>setSettings({...settings,mmap:e.target.checked})}/></div>
          <div className="toggle-row"><span>Jinja chat template</span><input type="checkbox" checked={settings.jinja} onChange={e=>setSettings({...settings,jinja:e.target.checked})}/></div>
          <div className="toggle-row"><span>Thinking / reasoning</span><input type="checkbox" checked={settings.thinking} onChange={e=>setSettings({...settings,thinking:e.target.checked})}/></div>
          <button className="secondary-btn" onClick={()=>setSettings(defaults)}><Settings2 size={16}/>Reset defaults</button>
        </section>}
      </div>
    </div>
  );
}

function Setting({label,value,min,max,step,onChange}:{label:string;value:number;min:number;max:number;step:number;onChange:(v:number)=>void}) {
  return <label className="setting"><div><span>{label}</span><b>{value}</b></div><input type="range" min={min} max={max} step={step} value={value} onChange={e=>onChange(Number(e.target.value))}/></label>
}

import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "dev.pocketpal.local",
  appName: "PocketPal Local",
  webDir: "dist",
  android: {
    backgroundColor: "#09090b"
  }
};

export default config;
